(function () {
    'use strict';
    angular.module('com.bmc.vyomlib.view-components.marquee1')
    	.directive('comBmcVyomlibMarquee1Design', function () {

        return {
            restrict: 'E',
            templateUrl: 'scripts/view-components/marquee1/com-bmc-vyomlib-marquee1-design.directive.html',

            scope: {
                rxConfiguration: '='
            }
        };
    });
})();