(function () {
    'use strict';
    angular.module('com.bmc.vyomlib.view-components.marquee1')
        .config(function (rxViewComponentProvider) {
        rxViewComponentProvider.registerComponent([
            {
                name: 'marquee1',
                group: 'vyomlib',
                icon: 'internet_plus_circle',
                type: 'com-bmc-vyomlib-marquee1',  
                designType: 'com-bmc-vyomlib-marquee1-design', 
				designManagerService: 'comBmcVyomlibMarquee1Design',
                bundleId: 'com.bmc.vyomlib',
                propertiesByName: [
					{
                        name: 'FieldID1',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
					{
                        name: 'FieldID1Title',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
					{
                        name: 'FieldID2',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
					{
                        name: 'FieldID2Title',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
					{
                        name: 'FieldID3',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
					{
                        name: 'FieldID3Title',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
					{
                        name: 'FieldID4',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
					{
                        name: 'FieldID4Title',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
                    {
                        name: 'ColourHeader',
                        isConfig: true,
                        type: 'string',
						defaultValue: 'black'
                    },
                    {
                        name: 'ColourText',
                        isConfig: true,
                        type: 'string',
						defaultValue: 'grey'

                    },
                    {
                        name: 'IncidentRecDef',
                        isConfig: true,
						//isRequired: true,
                        type: 'string'

                    },
                    {
                        name: 'FilterExp',
                        isConfig: true,
                        type: 'string'

                    }
                   
                    


                ]
            }
        ]);
    });
})();