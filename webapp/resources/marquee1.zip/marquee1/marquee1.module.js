(function () {
    'use strict';
    angular.module('com.bmc.vyomlib.view-components.marquee1', [
        'com.bmc.arsys.rx.standardlib.security',
        'com.bmc.arsys.rx.standardlib.view-component',
        'com.bmc.arsys.rx.standardlib.record.definition',
        'com.bmc.arsys.rx.standardlib.record.instance'
    ]);
})();