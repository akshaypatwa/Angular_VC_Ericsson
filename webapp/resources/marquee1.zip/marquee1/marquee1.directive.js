
(function () {
    'use strict';
    angular.module('com.bmc.vyomlib.view-components.marquee1')
        .directive('comBmcVyomlibMarquee1',

                   function (rxRecordInstanceDataPageResource,rxRecordInstanceResource, $window,rxViewComponentEventManager,rxCurrentUser,$timeout,rxString,$document,rxNotificationMessage,$sce,rxRecordDefinitionResource) {
        return {
            restrict: 'E',
            templateUrl: 'scripts/view-components/marquee1/com-bmc-vyomlib-marquee1.directive.html',

            scope: {
                rxConfiguration: '='
            },

                 link: function ($scope) {
                var _config;

                var init = function () {
                    _config = $scope.rxConfiguration.propertiesByName;
                   
                   
                    $scope.ColourHeader = _config.ColourHeader;
                    $scope.ColourText = _config.ColourText;
                    $scope.IncidentRecDef = _config.IncidentRecDef;
					$scope.FilterExp = _config.FilterExp;
					
					//console.log("((_config.FieldID1==null)||(_config.FieldID1==undefined)||(_config.FieldID1=='')): "+((_config.FieldID1==null)||(_config.FieldID1==undefined)||(_config.FieldID1=='')));
					//console.log("((_config.FieldID2==null)||(_config.FieldID2==undefined)||(_config.FieldID2=='')): "+((_config.FieldID2==null)||(_config.FieldID2==undefined)||(_config.FieldID2=='')));
					//console.log("((_config.FieldID3==null)||(_config.FieldID3==undefined)||(_config.FieldID3=='')): "+((_config.FieldID3==null)||(_config.FieldID3==undefined)||(_config.FieldID3=='')));
					//console.log("((_config.FieldID4==null)||(_config.FieldID4==undefined)||(_config.FieldID4=='')): "+((_config.FieldID4==null)||(_config.FieldID4==undefined)||(_config.FieldID4=='')));
                    
					$scope.FieldID1 = ((_config.FieldID1==null)||(_config.FieldID1==undefined)||(_config.FieldID1==''))?null:_config.FieldID1;
                    $scope.FieldID2 = ((_config.FieldID2==null)||(_config.FieldID2==undefined)||(_config.FieldID2==''))?null:_config.FieldID2;
					$scope.FieldID3 = ((_config.FieldID3==null)||(_config.FieldID3==undefined)||(_config.FieldID3==''))?null:_config.FieldID3;
                    $scope.FieldID4 = ((_config.FieldID4==null)||(_config.FieldID4==undefined)||(_config.FieldID4==''))?null:_config.FieldID4;
					
					$scope.FieldID1Title = ((_config.FieldID1Title==null)||(_config.FieldID1Title==undefined)||(_config.FieldID1Title==''))?null:_config.FieldID1Title;
					$scope.FieldID2Title = ((_config.FieldID2Title==null)||(_config.FieldID2Title==undefined)||(_config.FieldID2Title==''))?null:_config.FieldID2Title;
					$scope.FieldID3Title = ((_config.FieldID3Title==null)||(_config.FieldID3Title==undefined)||(_config.FieldID3Title==''))?null:_config.FieldID3Title;
					$scope.FieldID4Title = ((_config.FieldID4Title==null)||(_config.FieldID4Title==undefined)||(_config.FieldID4Title==''))?null:_config.FieldID4Title;
					
					//console.log("$scope.FieldIDs: "+$scope.FieldID1+" "+$scope.FieldID2+" "+$scope.FieldID3+" "+$scope.FieldID4);
					//console.log("$scope.FieldTitles: "+$scope.FieldID1Title+" "+$scope.FieldID2Title+" "+$scope.FieldID3Title+" "+$scope.FieldID4Title);
					//console.log("$scope.ColourHeader: "+$scope.ColourHeader+" $scope.ColourText: "+$scope.ColourText);
                
					//console.log("($scope.FieldID1==null): "+($scope.FieldID1==null));
					//console.log("($scope.FieldID1===null): "+($scope.FieldID1===null));
					//console.log("($scope.FieldID1==''): "+($scope.FieldID1==''));
					//console.log("($scope.FieldID1===''): "+($scope.FieldID1===''));
					
					 
					/* $scope.FieldID1 = _config.FieldID1==null?_config.FieldID1:_config.FieldID1.trim();
                    $scope.FieldID2 = _config.FieldID2==null?_config.FieldID2:_config.FieldID2.trim();
					$scope.FieldID3 = _config.FieldID3==null?_config.FieldID3:_config.FieldID3.trim();
                    $scope.FieldID4 = _config.FieldID4==null?_config.FieldID4:_config.FieldID4.trim(); */
					
					$scope.fields=[];
					if($scope.IncidentRecDef)
						$scope.getIncidentRec();
					//$scope.getList();
					//getFieldNames();
					console.log("$scope.mydata: "+angular.toJson($scope.mydata));
                    $scope.mydata=[];
					
                    $scope.statusValue=[];
					console.log("$scope.fields: "+angular.toJson($scope.fields));
                };
             
			function getFieldNames()
			{
				 // load Record Definition
                    rxRecordDefinitionResource.get($scope.IncidentRecDef).then(function (recordDefinition) {
                        $scope.IncRecordDefinition = recordDefinition;
						console.log("rxRecordDefinitionResource.get: $scope.IncRecordDefinition: "+angular.toJson($scope.IncRecordDefinition));
						console.log("$scope.IncRecordDefinition.fieldDefinitions: "+angular.toJson($scope.IncRecordDefinition.fieldDefinitions));
						console.log("getFieldNames(): "+angular.toJson(($scope.IncRecordDefinition.fieldDefinitions).map(function (fieldDefinition) {
                            return {
                                id: fieldDefinition.id,
                                name: fieldDefinition.name
                            };
                        })
                        ));
						$scope.fields=($scope.IncRecordDefinition.fieldDefinitions).map(function (fieldDefinition) {
                            return {
                                id: fieldDefinition.id,
                                name: fieldDefinition.name
                            };
                        });
						/*console.log("$scope.fields: "+angular.toJson($scope.fields));
						console.log("$scope.fields.find(x => x.id === 1);: "+$scope.fields.find(x => x.id === 1));
						console.log("$scope.fields.find(x => x.id === '1');: "+$scope.fields.find(x => x.id === '1'));
						console.log("$scope.fields.find(x => x.id == 1);: "+$scope.fields.find(x => x.id == 1));
						console.log("$scope.fields.find(x => x.id == '1');: "+$scope.fields.find(x => x.id == '1'));*/
						for (var i in $scope.fields) {
							console.log("typeof  $scope.fields[i].id : "+typeof $scope.fields[i].id ); 
						  
							console.log("$scope.fields[i].id == 1: "+$scope.fields[i].id == 1); // {a: 5, b: 6}
						 				
							console.log("Number($scope.fields[i].id) == 1: "+Number($scope.fields[i].id)==Number(1));
							console.log("$scope.fields[i].id == '1': "+$scope.fields[i].id == '1'); // {a: 5, b: 6}						 
						  
							console.log("$scope.fields[i].id === 1: "+$scope.fields[i].id === 1); // {a: 5, b: 6}
							console.log("Number($scope.fields[i].id) === 1: "+Number($scope.fields[i].id) ===Number(1));
							console.log("$scope.fields[i].id === '1': "+$scope.fields[i].id === '1'); // {a: 5, b: 6}
						 

						  console.log($scope.fields[i].id);
						}
                    }).catch(function (e) {
                        console.log("Unable to retrieve "+$scope.IncidentRecDef+" RecordDefinition."+e);
                    });
					
					
				
				
			}
			 
             $scope.getList=function()
			 {
				fLen = $scope.mydata.length;
				$scope.list="";
				//text = "<ul>";
				for (i = 0; i < fLen; i++) {
				  $scope.list += "<li>" + $scope.mydata[i][i+1] + "</li>";
				  $scope.list += "<li>" + $scope.mydata[i]['1'] + "</li>";
				  $scope.list += "<li>" + $scope.mydata[i][$scope.ColourHeader] + "</li>";
				  $scope.list += "<li>" + $scope.mydata[i][$scope.ColourText] + "</li>";
				  $scope.list += "<li>" + "|||||||" + "</li>";
				}
				//text += "</ul>";
			 }
  
            $scope.getIncidentRec=function()
                {
					console.log("$scope.IncidentRecDef: "+$scope.IncidentRecDef);
					var condition="";
					condition+=($scope.FieldID1==null||$scope.FieldID1=='')?"":($scope.FieldID1+",");
					condition+=($scope.FieldID2==null||$scope.FieldID2=='')?"":($scope.FieldID2+",");
					condition+=($scope.FieldID3==null||$scope.FieldID3=='')?"":($scope.FieldID3+",");
					condition+=($scope.FieldID4==null||$scope.FieldID4=='')?"":$scope.FieldID4;
					if(condition.charAt(condition.length-1)==",")
					{
						//console.log(" condition.charAt(condition.length-1)==','"+(condition.charAt(condition.length-1)==","));
						condition=condition.substring(0, condition.length - 1);
						console.log(" condition : "+condition);
					}
					//else console.log(condition+" condition.charAt(condition.length-1)==','"+(condition.charAt(condition.length-1)==","));
					
                    var foo = rxRecordInstanceDataPageResource.withName($scope.IncidentRecDef);
					 var queryParams = {
							//propertySelection:"1,"+$scope.ColourHeader+","+$scope.ColourText,//+","
							//propertySelection:"1,"+$scope.FieldID1+","+$scope.FieldID2+","+$scope.FieldID3+","+$scope.FieldID4,//+","
							propertySelection:"1,"+condition,//+","
                            //propertySelection: "179,7," + $scope.cfg.fieldIdToDisplay,//, // ids of fields to fetch
                            queryExpression: $scope.FilterExp?$scope.FilterExp:""//"'7' != 3" //Status is not rejected
                        };

                    foo.get(100, 0, queryParams).then(
                        function (allRecords) {
                            $scope.mydata = allRecords.data;
							consloe.log("$scope.mydata: "+angular.toJson($scope.mydata));
							$scope.mydatacopy = allRecords.data;
							fLen = allRecords.length;
							$scope.list="";
							//text = "<ul>";
							for (i = 0; i < fLen; i++) {
							  $scope.list += "<li>" + i+1 + "</li>";
							  $scope.list += "<li>" + allRecords[i]['1'] + "</li>";
							  $scope.list += "<li>" + allRecords[i][$scope.ColourHeader] + "</li>";
							  $scope.list += "<li>" + allRecords[i][$scope.ColourText] + "</li>";
							  $scope.list += "<li>" + "|||||||" + "</li>";
							}
							
							return $scope.mydata;
							
							// load Record Definition
								/*rxRecordDefinitionResource.get($scope.IncidentRecDef).then(function (recordDefinition) {
									$scope.IncRecordDefinition = recordDefinition;
									//console.log("rxRecordDefinitionResource.get: $scope.IncRecordDefinition: "+angular.toJson($scope.IncRecordDefinition));
									//console.log("$scope.IncRecordDefinition.fieldDefinitions: "+angular.toJson($scope.IncRecordDefinition.fieldDefinitions));
									//console.log("getFieldNames(): "+angular.toJson(($scope.IncRecordDefinition.fieldDefinitions).map(function (fieldDefinition) {return {id: fieldDefinition.id,name: fieldDefinition.name};})));
									$scope.fields=($scope.IncRecordDefinition.fieldDefinitions).map(function (fieldDefinition) {
										return {
											id: fieldDefinition.id,
											name: fieldDefinition.name
										};
									});
									
									($scope.mydatacopy).map(function (recordInstance) {
										console.log("recordInstance: "+recordInstance);
										for (var i in $scope.fields) 
										{
											console.log("$scope.fields[i].id: "+$scope.fields[i].id+" recordInstance['1']: "+recordInstance['1']);
											if($scope.fields[i].id==recordInstance['1'])
											{ 	
												return {
													id: fieldDefinition.id,
													name: fieldDefinition.name
												};
											}
										}
									});
									//console.log("$scope.fields: "+angular.toJson($scope.fields));
									//console.log("$scope.fields.find(x => x.id === 1);: "+$scope.fields.find(x => x.id === 1));
									//console.log("$scope.fields.find(x => x.id === '1');: "+$scope.fields.find(x => x.id === '1'));
									//console.log("$scope.fields.find(x => x.id == 1);: "+$scope.fields.find(x => x.id == 1));
									//console.log("$scope.fields.find(x => x.id == '1');: "+$scope.fields.find(x => x.id == '1'));
									for (var i in $scope.fields) {
										console.log("typeof  $scope.fields[i].id : "+typeof $scope.fields[i].id ); 
									  
										console.log("$scope.fields[i].id == 1: "+$scope.fields[i].id == 1); // {a: 5, b: 6}
													
										console.log("Number($scope.fields[i].id) == 1: "+Number($scope.fields[i].id)==Number(1));
										console.log("$scope.fields[i].id == '1': "+$scope.fields[i].id == '1'); // {a: 5, b: 6}						 
									  
										console.log("$scope.fields[i].id === 1: "+$scope.fields[i].id === 1); // {a: 5, b: 6}
										console.log("Number($scope.fields[i].id) === 1: "+Number($scope.fields[i].id) ===Number(1));
										console.log("$scope.fields[i].id === '1': "+$scope.fields[i].id === '1'); // {a: 5, b: 6}
									 

									  console.log($scope.fields[i].id);
									}
								}).catch(function (e) {
									console.log("Unable to retrieve "+$scope.IncidentRecDef+" RecordDefinition."+e);
								});*/
							
                        }
                    );
            

                    
                }
                     
                     
                     
                     

                init();

            }

        };
    });
})();



























//
//(function () {
//    'use strict';
//    angular.module('com.bmc.vyomlib.view-components.marquee')
//        .directive('comVyomVyomlibMarquee',
//
//                   function (rxRecordInstanceDataPageResource,rxRecordInstanceResource, $window,rxViewComponentEventManager,rxCurrentUser,$timeout,rxString,$document,rxNotificationMessage,$sce) {
//        return {
//            restrict: 'E',
//            templateUrl: 'scripts/view-components/marquee/com-bmc-vyomlib-marquee.directive.html',
//
//            scope: {
//                rxConfiguration: '='
//            },
//
//            link: function ($scope) {
//                var _config;
//
//                var init = function () {
//                    _config = $scope.rxConfiguration.propertiesByName;
//                    $scope.ColourHeader=_config.ColourHeader;
//                    $scope.ColourMain=_config.ColourMain;
//                    $scope.IncidentRecDef=_config.IncidentRecDef;
//                    
//                    $scope.getIncidentRec();
//                    $scope.mydata=[];
//                    $scope.statusValue=[];  
//                  
//                };             
//
//                // <!----------- buit in functions------------------>
//                
////                $scope.getIncidentRec=function()
////                {
////                         var foo = rxRecordInstanceDataPageResource.withName($scope.IncidentRecDef);
////
////                    foo.get(100, 0, { propertySelection:"2,179,1,7,8,"
////                                    }).then(
////                        function (allRecords) {
////                            $scope.mydata = allRecords.data;
////     
////
////                        }
////                    );            
////                            
////                }
//                
//                init();
//
//            }
//
//        };
//    });
//})();